import asyncio
import os
import subprocess
from typing import Any

from aiohttp import web

from ..live_runtime.broker import RealtimeBroker
from ..live_runtime.normalize import to_transport_safe
from ..config import OFFROAD_ASSETS_DIR
from ..services.device_info import get_calibration_status, get_device_network
from ..services.params import HAS_PARAMS, Params, restore_param_values_validated
from ..services.settings import get_settings_cached
from ..services.time_sync import TIME_SYNC_DEBUG_DEFAULT, sync_system_time_from_browser


_LIVE_RUNTIME_SERVICE_NAMES = (
  "selfdriveState",
  "carState",
  "controlsState",
  "deviceState",
  "peripheralState",
  "longitudinalPlan",
  "lateralPlan",
  "radarState",
  "carrotMan",
)

_CARROT_DEFAULT_RESET_EXCLUDED_NAMES = {
  # Vehicle identity / selection / fingerprinting.
  "CarName",
  "CarParams",
  "CarParamsCache",
  "CarParamsPersistent",
  "CarParamsPrevRoute",
  "CarModel",
  "CarFingerprint",
  "SupportedCars",
  # Training, terms, calibration, and learned live parameters.
  "CompletedTrainingVersion",
  "TrainingVersion",
  "TermsVersion",
  "HasAcceptedTerms",
  "CalibrationParams",
  "LiveParameters",
  "LiveTorqueParameters",
  # Device/user/system identity and platform settings.
  "DongleId",
  "HardwareSerial",
  "DeviceSerial",
  "DeviceType",
  "LanguageSetting",
  "IsMetric",
  "OpenpilotEnabledToggle",
  "ExperimentalMode",
  "ExperimentalModeConfirmed",
  "SshEnabled",
  "AdbEnabled",
  "GithubUsername",
  "GithubSshKeys",
  # Recording/upload/update/git state should not be reset by Carrot tuning reset.
  "RecordFront",
  "RecordAudio",
  "GitBranch",
  "GitCommit",
  "GitCommitDate",
  "UpdaterState",
  "UpdaterTargetBranch",
  "UpdaterCurrentDescription",
}

_CARROT_DEFAULT_RESET_EXCLUDED_PREFIXES = (
  "CarParams",
  "Calibration",
  "CompletedTraining",
  "Git",
  "Github",
  "Updater",
  "Dongle",
  "Hardware",
  "DeviceSerial",
)


def _is_carrot_default_reset_param(name: str, meta: Any) -> bool:
  if not name or not isinstance(meta, dict) or "default" not in meta:
    return False
  if name in _CARROT_DEFAULT_RESET_EXCLUDED_NAMES:
    return False
  return not any(name.startswith(prefix) for prefix in _CARROT_DEFAULT_RESET_EXCLUDED_PREFIXES)


def _select_live_runtime_services(snapshot: dict[str, Any]) -> dict[str, Any]:
  services = snapshot.get("services")
  if not isinstance(services, dict):
    return {}
  out: dict[str, Any] = {}
  for name in _LIVE_RUNTIME_SERVICE_NAMES:
    value = services.get(name)
    if isinstance(value, dict):
      out[name] = value
  return out


def _is_drive_engaged(request: web.Request) -> bool:
  broker: RealtimeBroker | None = request.app.get("realtime_broker")
  snapshot = broker.last_snapshot if broker is not None and isinstance(broker.last_snapshot, dict) else {}
  services = snapshot.get("services") if isinstance(snapshot, dict) else {}
  if not isinstance(services, dict):
    return False

  for service_name in ("selfdriveState", "controlsState"):
    service = services.get(service_name)
    if isinstance(service, dict) and bool(service.get("enabled")):
      return True
  return False


def _reject_if_engaged(request: web.Request) -> web.Response | None:
  if not _is_drive_engaged(request):
    return None
  return web.json_response({"ok": False, "error": "Disengage first"}, status=409)


async def api_heartbeat_status(request: web.Request) -> web.Response:
  return web.json_response({"ok": True, "hb": request.app.get("hb_last")})


async def api_live_runtime(request: web.Request) -> web.Response:
  broker: RealtimeBroker | None = request.app.get("realtime_broker")
  broker_error = request.app.get("realtime_broker_error")
  if broker is None:
    return web.json_response({"ok": False, "error": broker_error or "realtime broker unavailable"}, status=503)

  force = request.query.get("force") == "1"
  runtime = broker.last_snapshot.get("runtime") if isinstance(broker.last_snapshot, dict) else None
  if not isinstance(runtime, dict):
    runtime = {}

  age_ms = broker.snapshot_age_ms()
  if force or age_ms is None or age_ms > 250 or not runtime.get("params"):
    # Serialize poll across concurrent requests: broker.poll() runs
    # SubMaster.update(), and msgq's SubMaster is NOT thread-safe — parallel
    # polls (multiple tabs/devices hitting /api/live_runtime) can corrupt or
    # crash it and take the whole server down. Re-check freshness inside the
    # lock so a request that waited skips a now-redundant poll.
    lock = request.app.get("realtime_broker_poll_lock")
    try:
      if lock is not None:
        async with lock:
          fresh_age = broker.snapshot_age_ms()
          fresh_runtime = broker.last_snapshot.get("runtime") if isinstance(broker.last_snapshot, dict) else {}
          if force or fresh_age is None or fresh_age > 250 or not (fresh_runtime or {}).get("params"):
            await asyncio.to_thread(broker.poll, 0)
      else:
        await asyncio.to_thread(broker.poll, 0)
    except Exception as exc:
      return web.json_response({"ok": False, "error": str(exc)}, status=500)
    runtime = broker.last_snapshot.get("runtime") if isinstance(broker.last_snapshot, dict) else {}

  meta = broker.last_snapshot.get("meta") if isinstance(broker.last_snapshot, dict) else {}
  services = _select_live_runtime_services(broker.last_snapshot if isinstance(broker.last_snapshot, dict) else {})
  return web.json_response(to_transport_safe({
    "ok": True,
    "meta": meta if isinstance(meta, dict) else {},
    "runtime": runtime if isinstance(runtime, dict) else {},
    "services": services,
    "snapshotAgeMs": broker.snapshot_age_ms(),
  }))


async def api_reboot(request: web.Request) -> web.Response:
  blocked = _reject_if_engaged(request)
  if blocked is not None:
    return blocked
  try:
    if HAS_PARAMS:
      Params().put_bool("DoReboot", True)
    else:
      # Params-less development fallback only.
      subprocess.Popen(["sudo", "reboot"])
    return web.json_response({"ok": True})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_time_sync(request: web.Request) -> web.Response:
  try:
    body = await request.json()
  except Exception as e:
    return web.json_response({"ok": False, "error": f"bad json: {e}"}, status=400)

  epoch_ms = body.get("epoch_ms")
  timezone_name = (body.get("timezone") or "").strip()
  debug = bool(body.get("debug", False))
  client_iso = body.get("client_iso")

  if not isinstance(epoch_ms, (int, float)):
    return web.json_response({"ok": False, "error": "epoch_ms required"}, status=400)

  if not timezone_name:
    timezone_name = "UTC"

  effective_debug = debug or TIME_SYNC_DEBUG_DEFAULT
  if effective_debug:
    print(f"[time_sync] client={request.remote} timezone={timezone_name} client_iso={client_iso} debug={debug}")

  result = await asyncio.to_thread(
    sync_system_time_from_browser,
    int(epoch_ms),
    timezone_name,
    effective_debug,
  )

  if effective_debug:
    print(
      f"[time_sync] result ok={result.get('ok')} "
      f"applied={result.get('applied')} "
      f"diff_sec={result.get('diff_sec')} "
      f"message={result.get('message')}"
    )

  status = 200 if result.get("ok") else 500
  return web.json_response(result, status=status)


async def api_device_network(request: web.Request) -> web.Response:
  try:
    force = request.query.get("force") == "1"
    network = await asyncio.to_thread(get_device_network, force)
    return web.json_response({"ok": True, "network": network})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_calibration_status(request: web.Request) -> web.Response:
  try:
    calibration = await asyncio.to_thread(get_calibration_status)
    return web.json_response({"ok": True, "calibration": calibration})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_regulatory(request: web.Request) -> web.Response:
  try:
    path = os.path.join(OFFROAD_ASSETS_DIR, "fcc.html")
    if not os.path.isfile(path):
      return web.json_response({"ok": False, "error": "regulatory info unavailable"}, status=404)

    def read_file() -> str:
      with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()

    html = await asyncio.to_thread(read_file)
    return web.json_response({"ok": True, "html": html})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_poweroff(request: web.Request) -> web.Response:
  blocked = _reject_if_engaged(request)
  if blocked is not None:
    return blocked
  if not HAS_PARAMS:
    return web.json_response({"ok": False, "error": "params unavailable"}, status=500)
  try:
    Params().put_bool("DoShutdown", True)
    return web.json_response({"ok": True})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_recalibrate(request: web.Request) -> web.Response:
  blocked = _reject_if_engaged(request)
  if blocked is not None:
    return blocked
  if not HAS_PARAMS:
    return web.json_response({"ok": False, "error": "params unavailable"}, status=500)
  try:
    params = Params()
    for key in ("CalibrationParams", "LiveTorqueParameters",
                "LiveParameters", "LiveParametersV2", "LiveDelay"):
      try:
        params.remove(key)
      except Exception:
        pass
    # Request onroad cycle restart if available
    try:
      params.put_bool("OnroadCycleRequested", True)
    except Exception:
      pass
    try:
      params.put_bool("DoReboot", True)
    except Exception:
      pass
    return web.json_response({"ok": True})
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


async def api_set_default(request: web.Request) -> web.Response:
  if not HAS_PARAMS:
    return web.json_response({"ok": False, "error": "params unavailable"}, status=500)
  try:
    _, _, by_name, _ = get_settings_cached()
    values = {
      name: meta.get("default", 0)
      for name, meta in by_name.items()
      if _is_carrot_default_reset_param(name, meta)
    }
    restored = restore_param_values_validated(values)
    result = restored.get("result") or {}
    ok = int(result.get("fail_cnt") or 0) == 0
    applied_values = {
      entry["key"]: entry["value"]
      for entry in restored.get("preview", {}).get("entries", [])
      if entry.get("apply")
    }
    status = 200 if ok else 500
    return web.json_response({
      "ok": ok,
      "message": "설정 초기화 성공" if ok else "설정 초기화 실패",
      "error": None if ok else "설정 초기화 실패",
      "values": applied_values,
      **restored,
    }, status=status)
  except Exception as e:
    return web.json_response({"ok": False, "error": str(e)}, status=500)


def register(app: web.Application) -> None:
  app.router.add_get("/api/heartbeat_status", api_heartbeat_status)
  app.router.add_get("/api/live_runtime", api_live_runtime)
  app.router.add_get("/api/device_network", api_device_network)
  app.router.add_get("/api/calibration_status", api_calibration_status)
  app.router.add_get("/api/regulatory", api_regulatory)
  app.router.add_post("/api/reboot", api_reboot)
  app.router.add_post("/api/poweroff", api_poweroff)
  app.router.add_post("/api/recalibrate", api_recalibrate)
  app.router.add_post("/api/set_default", api_set_default)
  app.router.add_post("/api/time_sync", api_time_sync)
